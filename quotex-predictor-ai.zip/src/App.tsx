import React, { useState, useEffect } from "react";
import { PredictionResult, TradeHistoryItem } from "./types";
import UploadZone from "./components/UploadZone";
import PredictionCard from "./components/PredictionCard";
import GuideSection from "./components/GuideSection";
import HistoryList from "./components/HistoryList";
import { TrendingUp, Sparkles, RefreshCw, Layers, Compass, BarChart3, AlertCircle, Maximize2, X } from "lucide-react";

export default function App() {
  // Application State
  const [screenshot, setScreenshot] = useState<string | null>(null);
  const [additionalContext, setAdditionalContext] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<TradeHistoryItem[]>([]);
  const [activeTab, setActiveTab] = useState<"workspace" | "history">("workspace");
  const [zoomImage, setZoomImage] = useState<string | null>(null);

  // Load history from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem("quotex_prediction_history");
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (err) {
        console.error("Failed to parse trading history:", err);
      }
    }
  }, []);

  // Save history helper
  const saveHistory = (updatedHistory: TradeHistoryItem[]) => {
    setHistory(updatedHistory);
    localStorage.setItem("quotex_prediction_history", JSON.stringify(updatedHistory));
  };

  // Submit screenshot for prediction
  const handleAnalyzeTrade = async () => {
    if (!screenshot) return;

    setIsAnalyzing(true);
    setError(null);
    setPrediction(null);

    try {
      const response = await fetch("/api/predict", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          image: screenshot,
          additionalContext: additionalContext,
        }),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Failed to analyze trade screenshot");
      }

      const result: PredictionResult = await response.json();
      setPrediction(result);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An unexpected error occurred during prediction.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Save current prediction to history
  const handleSaveToHistory = () => {
    if (!screenshot || !prediction) return;

    // Check if already saved (prevent duplicates)
    const exists = history.some(
      (h) => h.screenshotUrl === screenshot && h.prediction.prediction === prediction.prediction
    );
    if (exists) return;

    const newItem: TradeHistoryItem = {
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      screenshotUrl: screenshot,
      additionalContext: additionalContext,
      prediction: prediction,
      userOutcome: "UNRESOLVED",
    };

    const updated = [newItem, ...history];
    saveHistory(updated);
  };

  // Update outcome (Win/Loss) of an existing item
  const handleSetOutcome = (id: string, outcome: "WIN" | "LOSS") => {
    const updated = history.map((item) => {
      if (item.id === id) {
        return {
          ...item,
          userOutcome: item.userOutcome === outcome ? ("UNRESOLVED" as const) : outcome,
        };
      }
      return item;
    });
    saveHistory(updated);
  };

  // Delete a history item
  const handleDeleteHistoryItem = (id: string) => {
    const updated = history.filter((item) => item.id !== id);
    saveHistory(updated);
  };

  // Clear all history
  const handleClearAllHistory = () => {
    if (window.confirm("Are you sure you want to clear your entire trade prediction portfolio?")) {
      saveHistory([]);
    }
  };

  // Load an item from history back into the workspace to inspect it
  const handleLoadHistoryItem = (item: TradeHistoryItem) => {
    setScreenshot(item.screenshotUrl);
    setAdditionalContext(item.additionalContext || "");
    setPrediction(item.prediction);
    setActiveTab("workspace");
    // Scroll to top of the page
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Clear the current workspace
  const handleClearWorkspace = () => {
    setScreenshot(null);
    setPrediction(null);
    setAdditionalContext("");
    setError(null);
  };

  // Calculate the live statistics
  const totalWithOutcome = history.filter((h) => h.userOutcome === "WIN" || h.userOutcome === "LOSS");
  const wins = history.filter((h) => h.userOutcome === "WIN").length;
  const winRate = totalWithOutcome.length > 0 ? Math.round((wins / totalWithOutcome.length) * 100) : 0;

  // Check if current workspace item is already saved
  const isCurrentPredictionSaved = history.some(
    (h) => h.screenshotUrl === screenshot && h.prediction.prediction === prediction?.prediction
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 bg-grid-pattern pb-12">
      {/* Header Bar */}
      <header className="sticky top-0 z-10 backdrop-blur-md bg-slate-950/80 border-b border-slate-900 px-4 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="absolute inset-0 rounded-lg bg-emerald-500/20 blur-md animate-pulse"></div>
              <div className="relative bg-slate-900 border border-emerald-500/30 p-2 rounded-lg">
                <TrendingUp className="w-5 h-5 text-emerald-400" />
              </div>
            </div>
            <div>
              <h1 className="font-display font-bold text-lg leading-none tracking-tight text-slate-100">
                QUOTEX <span className="text-emerald-400">PREDICTOR AI</span>
              </h1>
              <p className="text-[10px] font-mono text-slate-500 mt-0.5 tracking-wider uppercase">
                Expert Neural Signal Assistant
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {totalWithOutcome.length > 0 && (
              <div className="hidden sm:flex items-center gap-2 bg-slate-900/60 border border-slate-800/80 px-3 py-1.5 rounded-lg text-xs font-mono">
                <span className="text-slate-500">Live Win-Rate:</span>
                <span className="text-emerald-400 font-bold">{winRate}%</span>
                <span className="text-slate-600">|</span>
                <span className="text-slate-400">{wins}/{totalWithOutcome.length} Won</span>
              </div>
            )}
            <span className="text-xs font-mono bg-slate-900 text-slate-400 border border-slate-800 px-2.5 py-1.5 rounded-lg">
              UTC Local Time
            </span>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 mt-8">
        {/* Navigation Tabs for Mobile and Desktop context division */}
        <div className="flex border-b border-slate-900 mb-6 gap-2">
          <button
            onClick={() => setActiveTab("workspace")}
            className={`px-5 py-3 font-display font-medium text-sm border-b-2 transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === "workspace"
                ? "border-emerald-500 text-slate-100"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Compass className="w-4 h-4" /> Signal Workspace
          </button>
          <button
            onClick={() => setActiveTab("history")}
            className={`px-5 py-3 font-display font-medium text-sm border-b-2 transition-all cursor-pointer flex items-center gap-2 relative ${
              activeTab === "history"
                ? "border-emerald-500 text-slate-100"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Layers className="w-4 h-4" /> History Journal Portfolio
            {history.length > 0 && (
              <span className="absolute top-2.5 right-1 w-2 h-2 rounded-full bg-emerald-500"></span>
            )}
          </button>
        </div>

        {/* Tab content 1: Workspace */}
        {activeTab === "workspace" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Hand: Upload Area + Options (8 Cols) */}
            <div className="lg:col-span-7 space-y-6">
              <div className="bg-slate-900/40 border border-slate-900 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="font-display font-semibold text-slate-200 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    Trading Asset Signal Area
                  </h2>
                  {screenshot && (
                    <button
                      onClick={handleClearWorkspace}
                      className="text-xs text-slate-500 hover:text-slate-400 font-mono transition-colors cursor-pointer"
                    >
                      Reset Workspace
                    </button>
                  )}
                </div>

                <UploadZone
                  onImageSelected={setScreenshot}
                  selectedImage={screenshot}
                  onClear={handleClearWorkspace}
                  isAnalyzing={isAnalyzing}
                />

                {/* Additional context input for trade refinement */}
                {screenshot && (
                  <div className="mt-5 space-y-2">
                    <label className="block text-xs font-mono text-slate-400 uppercase">
                      Trading Pair / Timeframe Context (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. EUR/USD OTC, 1-Minute candles, current trend is bearish"
                      value={additionalContext}
                      onChange={(e) => setAdditionalContext(e.target.value)}
                      disabled={isAnalyzing}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500/50 rounded-lg px-3.5 py-2.5 text-sm text-slate-200 placeholder:text-slate-600 outline-none transition-all"
                    />
                  </div>
                )}

                {/* Action Trigger Button */}
                {screenshot && (
                  <button
                    onClick={handleAnalyzeTrade}
                    disabled={isAnalyzing}
                    className="w-full mt-5 py-3.5 px-4 bg-emerald-500 hover:bg-emerald-400 disabled:bg-slate-850 disabled:text-slate-600 rounded-xl text-slate-950 font-bold tracking-wide transition-all shadow-lg hover:shadow-emerald-500/10 flex items-center justify-center gap-2 cursor-pointer disabled:cursor-not-allowed"
                  >
                    {isAnalyzing ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        AI Market Analysis in Progress...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        Calculate AI Signal Prediction
                      </>
                    )}
                  </button>
                )}
              </div>

              {/* Instructional Guidelines Card */}
              <GuideSection />
            </div>

            {/* Right Hand: Signal Feedback (5 Cols) */}
            <div className="lg:col-span-5 space-y-6">
              {error && (
                <div className="p-4 bg-rose-500/10 border border-rose-500/20 rounded-xl flex gap-3 text-sm text-rose-400">
                  <AlertCircle className="w-5 h-5 shrink-0 text-rose-500" />
                  <div>
                    <span className="font-semibold block mb-0.5">Prediction Failed</span>
                    <span>{error}</span>
                  </div>
                </div>
              )}

              {isAnalyzing && (
                <div className="bg-slate-900/30 border border-slate-900 rounded-xl p-8 text-center space-y-4">
                  <div className="relative w-16 h-16 mx-auto">
                    <div className="absolute inset-0 rounded-full border-4 border-emerald-500/10"></div>
                    <div className="absolute inset-0 rounded-full border-4 border-emerald-500 border-t-transparent animate-spin"></div>
                  </div>
                  <div>
                    <h3 className="font-display font-medium text-slate-200">Evaluating Market Vectors</h3>
                    <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                      Analyzing candlestick wicks, support floors, momentum indicator overlays, and volume structures from the screenshot.
                    </p>
                  </div>
                </div>
              )}

              {!prediction && !isAnalyzing && !error && (
                <div className="bg-slate-900/10 border border-dashed border-slate-900 rounded-xl p-8 text-center text-slate-500">
                  <BarChart3 className="w-8 h-8 mx-auto text-slate-800 mb-2" />
                  <p className="text-sm font-medium text-slate-400">Awaiting Chart Upload</p>
                  <p className="text-xs text-slate-600 mt-1 max-w-xs mx-auto">
                    Provide a screenshot of your Quotex chart workspace. The AI will compute precise entry thresholds and trade directions.
                  </p>
                </div>
              )}

              {prediction && !isAnalyzing && (
                <div className="animate-in fade-in slide-in-from-bottom-3 duration-300">
                  <PredictionCard
                    prediction={prediction}
                    onSave={handleSaveToHistory}
                    isSaved={isCurrentPredictionSaved}
                  />
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab content 2: Journal History */}
        {activeTab === "history" && (
          <div className="max-w-4xl mx-auto">
            <HistoryList
              history={history}
              onSetOutcome={handleSetOutcome}
              onDelete={handleDeleteHistoryItem}
              onClearAll={handleClearAllHistory}
              onLoadItem={handleLoadHistoryItem}
            />
          </div>
        )}
      </main>

      {/* Image zoom overlay modal */}
      {zoomImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
          <div className="relative max-w-5xl w-full max-h-[85vh] bg-slate-900 rounded-xl overflow-hidden border border-slate-800 p-2 flex flex-col">
            <button
              onClick={() => setZoomImage(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-950/80 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800 z-10 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="flex-1 overflow-auto flex items-center justify-center">
              <img
                src={zoomImage}
                alt="Enlarged Chart"
                className="max-h-[75vh] object-contain w-full"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
