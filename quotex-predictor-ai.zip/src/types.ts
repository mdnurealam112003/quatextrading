export interface PredictionResult {
  prediction: "UP" | "DOWN" | "HOLD";
  confidence: number;
  recommendedTimeframe: string;
  priceAction: string;
  keyPatterns: string[];
  technicalIndicators: string;
  safeMargin: string;
  riskLevel: "LOW" | "MEDIUM" | "HIGH";
  justification: string;
}

export interface TradeHistoryItem {
  id: string;
  timestamp: string;
  screenshotUrl: string;
  additionalContext?: string;
  prediction: PredictionResult;
  userOutcome?: "WIN" | "LOSS" | "UNRESOLVED";
  notes?: string;
}
