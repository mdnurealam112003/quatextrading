import React from "react";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  LineChart,
  Line,
} from "recharts";
import { TradeHistoryItem } from "../types";
import { TrendingUp, ShieldCheck, Activity, AlertCircle } from "lucide-react";

interface HistoryVisualizerProps {
  history: TradeHistoryItem[];
}

export default function HistoryVisualizer({ history }: HistoryVisualizerProps) {
  // Filter history items with resolved outcomes (WIN/LOSS)
  const resolvedTrades = [...history]
    .filter((h) => h.userOutcome === "WIN" || h.userOutcome === "LOSS")
    // Sort chronologically (oldest to newest) to show progress over time
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  if (resolvedTrades.length === 0) {
    return (
      <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-6 text-center text-slate-400">
        <Activity className="w-6 h-6 text-slate-600 mx-auto mb-2" />
        <h4 className="font-display font-medium text-slate-300 text-sm">No Resolved Trade Data Yet</h4>
        <p className="text-xs text-slate-500 mt-1">
          Mark some predictions as **WIN** or **LOSS** in the journal below to see success charts and accuracy metrics.
        </p>
      </div>
    );
  }

  // Generate data points for running Win Rate
  let accumulatedWins = 0;
  let accumulatedLosses = 0;

  const chartData = resolvedTrades.map((trade, idx) => {
    const date = new Date(trade.timestamp);
    const label = date.toLocaleDateString([], { month: "short", day: "numeric" }) + " " + date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

    if (trade.userOutcome === "WIN") {
      accumulatedWins++;
    } else if (trade.userOutcome === "LOSS") {
      accumulatedLosses++;
    }

    const totalTrades = accumulatedWins + accumulatedLosses;
    const currentWinRate = totalTrades > 0 ? Math.round((accumulatedWins / totalTrades) * 100) : 0;

    return {
      index: idx + 1,
      label,
      outcome: trade.userOutcome,
      confidence: trade.prediction.confidence,
      winRate: currentWinRate,
      winCount: accumulatedWins,
      lossCount: accumulatedLosses,
    };
  });

  return (
    <div className="space-y-6">
      {/* Title & Section Header */}
      <div className="border-b border-slate-800/60 pb-3">
        <h3 className="font-display font-semibold text-slate-200 text-base flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-emerald-400" />
          Accuracy & Signal Performance Visualizer
        </h3>
        <p className="text-xs text-slate-500 font-mono mt-0.5">
          TRACKING {resolvedTrades.length} RESOLVED SIGNAL POSITION EVENTS
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Chart 1: Running Accuracy & Win Rate Trend */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-3 flex items-center justify-between">
              <span>Win-Rate Performance Trend</span>
              <span className="text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded">
                Target: &gt;80%
              </span>
            </h4>
          </div>

          <div className="w-full h-56 min-h-[224px] mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorWinRate" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="index" stroke="#475569" fontSize={10} fontFamily="monospace" />
                <YAxis
                  domain={[0, 100]}
                  tickFormatter={(val) => `${val}%`}
                  stroke="#475569"
                  fontSize={10}
                  fontFamily="monospace"
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#0f172a",
                    borderColor: "#334155",
                    borderRadius: "8px",
                    color: "#f8fafc",
                    fontFamily: "monospace",
                    fontSize: "12px",
                  }}
                  formatter={(value: any) => [`${value}%`, "Cumulative Win Rate"]}
                  labelFormatter={(labelIdx: any) => {
                    const idx = Number(labelIdx) - 1;
                    return chartData[idx]?.label || `Trade #${labelIdx}`;
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="winRate"
                  stroke="#10b981"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorWinRate)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[10px] text-slate-500 font-sans mt-3 text-center">
            Chronological performance line showing cumulative trade session accuracy.
          </p>
        </div>

        {/* Chart 2: Model Confidence vs Trade Outcomes */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-3 flex items-center justify-between">
              <span>Model Confidence vs Actual Outcome</span>
              <span className="text-slate-500 text-[10px]">ANALYSIS CORRELATION</span>
            </h4>
          </div>

          <div className="w-full h-56 min-h-[224px] mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="index" stroke="#475569" fontSize={10} fontFamily="monospace" />
                <YAxis domain={[0, 100]} stroke="#475569" fontSize={10} fontFamily="monospace" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#0f172a",
                    borderColor: "#334155",
                    borderRadius: "8px",
                    color: "#f8fafc",
                    fontFamily: "monospace",
                    fontSize: "12px",
                  }}
                  formatter={(value: any, name: any, props: any) => {
                    const outcome = props.payload.outcome;
                    return [
                      `${value}%`,
                      `Confidence (Result: ${outcome})`,
                    ];
                  }}
                  labelFormatter={(labelIdx: any) => {
                    const idx = Number(labelIdx) - 1;
                    return chartData[idx]?.label || `Trade #${labelIdx}`;
                  }}
                />
                <Bar
                  dataKey="confidence"
                  radius={[4, 4, 0, 0]}
                  fill="#6366f1"
                  maxBarSize={30}
                >
                  {chartData.map((entry, index) => (
                    <rect
                      key={`rect-${index}`}
                      fill={entry.outcome === "WIN" ? "rgba(16, 185, 129, 0.7)" : "rgba(244, 63, 94, 0.7)"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[10px] text-slate-500 font-sans mt-3 text-center">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500/70 mr-1"></span> Win Signal
            <span className="inline-block w-2 h-2 rounded-full bg-rose-500/70 ml-3 mr-1"></span> Loss Signal (Visualizes confidence vs success)
          </p>
        </div>
      </div>
    </div>
  );
}
