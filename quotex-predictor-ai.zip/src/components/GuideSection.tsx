import React from "react";
import { CheckCircle, AlertTriangle, Eye, HelpCircle } from "lucide-react";

export default function GuideSection() {
  return (
    <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-5 w-full">
      <h3 className="font-display font-semibold text-slate-200 text-lg mb-4 flex items-center gap-2">
        <HelpCircle className="w-5 h-5 text-emerald-400" />
        How to get 95%+ Accuracy Signals
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Do's */}
        <div className="space-y-3">
          <h4 className="text-xs font-mono text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
            <CheckCircle className="w-4 h-4 text-emerald-500" /> Good Screenshot Rules
          </h4>
          <ul className="space-y-2.5 text-sm text-slate-300">
            <li className="flex items-start gap-2">
              <span className="text-emerald-500 font-bold shrink-0">✓</span>
              <span>
                Use <strong>Candlestick charts</strong> (not lines or area) so the AI can examine candle bodies, shadows, and wicks.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-500 font-bold shrink-0">✓</span>
              <span>
                Zoom in moderately so at least <strong>25–50 candles</strong> are clearly visible, illustrating the immediate trend structure.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-500 font-bold shrink-0">✓</span>
              <span>
                Keep indicators active if you use them (e.g., <strong>RSI, MACD, Bollinger Bands, or Moving Averages</strong>).
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-500 font-bold shrink-0">✓</span>
              <span>
                Capture the <strong>timeframe selector</strong> (e.g., 1M, 5M) so the AI can suggest the ideal expiration timer.
              </span>
            </li>
          </ul>
        </div>

        {/* Don'ts & Quick Tip */}
        <div className="space-y-3 flex flex-col justify-between">
          <div>
            <h4 className="text-xs font-mono text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-500" /> Avoid These Mistakes
            </h4>
            <ul className="space-y-2.5 text-sm text-slate-300 mt-2.5">
              <li className="flex items-start gap-2">
                <span className="text-rose-500 font-bold shrink-0">✗</span>
                <span>Screenshots that are extremely zoomed out or blurry where individual candles cannot be resolved.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-500 font-bold shrink-0">✗</span>
                <span>Uploading screenshots of your wallet or transaction logs instead of the actual asset chart area.</span>
              </li>
            </ul>
          </div>

          <div className="bg-slate-950/50 rounded-lg p-3.5 border border-slate-800 text-xs text-slate-400 mt-2">
            <span className="font-semibold text-slate-300 flex items-center gap-1 mb-1">
              <Eye className="w-3.5 h-3.5 text-slate-400" /> Professional Tip:
            </span>
            Press <kbd className="px-1 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[10px]">PrtScn</kbd> or <kbd className="px-1 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[10px]">Cmd+Shift+4</kbd> on Quotex, then click on this page and press <kbd className="px-1 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[10px]">Ctrl+V</kbd> to paste immediately for lightning-fast trading signals!
          </div>
        </div>
      </div>
    </div>
  );
}
