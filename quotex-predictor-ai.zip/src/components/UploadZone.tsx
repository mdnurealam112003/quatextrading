import React, { useState, useEffect, useRef } from "react";
import { Upload, Image as ImageIcon, Clipboard, AlertCircle, X } from "lucide-react";

interface UploadZoneProps {
  onImageSelected: (base64Image: string) => void;
  selectedImage: string | null;
  onClear: () => void;
  isAnalyzing: boolean;
}

export default function UploadZone({
  onImageSelected,
  selectedImage,
  onClear,
  isAnalyzing,
}: UploadZoneProps) {
  const [isDragActive, setIsDragActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Clipboard paste listener
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      if (isAnalyzing || selectedImage) return;

      const items = e.clipboardData?.items;
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf("image") !== -1) {
          const file = items[i].getAsFile();
          if (file) {
            processFile(file);
            break;
          }
        }
      }
    };

    window.addEventListener("paste", handlePaste);
    return () => {
      window.removeEventListener("paste", handlePaste);
    };
  }, [isAnalyzing, selectedImage]);

  const processFile = (file: File) => {
    setError(null);

    // Validate size (limit to 10MB)
    if (file.size > 10 * 1024 * 1024) {
      setError("File is too large. Please upload an image smaller than 10MB.");
      return;
    }

    if (!file.type.startsWith("image/")) {
      setError("Unsupported file format. Please upload an image (PNG, JPG, or WEBP).");
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        onImageSelected(result);
      } else {
        setError("Could not read image file. Please try again.");
      }
    };
    reader.onerror = () => {
      setError("An error occurred while reading the file.");
    };
    reader.readAsDataURL(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragActive(true);
    } else if (e.type === "dragleave") {
      setIsDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <div className="w-full">
      {error && (
        <div className="mb-4 flex items-center gap-2 p-3 text-sm rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {selectedImage ? (
        <div className="relative w-full aspect-video md:aspect-[16/9] rounded-xl overflow-hidden border border-slate-800 bg-slate-900 group">
          <img
            src={selectedImage}
            alt="Quotex Chart Screenshot"
            className="w-full h-full object-contain"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
            <button
              onClick={onClear}
              disabled={isAnalyzing}
              className="p-2.5 rounded-full bg-slate-900/90 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700/50 transition-colors cursor-pointer"
              title="Remove screenshot"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="absolute bottom-3 left-3 bg-slate-950/80 backdrop-blur-md px-2.5 py-1 rounded text-xs font-mono text-slate-400 border border-slate-800">
            Screenshot Loaded
          </div>
        </div>
      ) : (
        <div
          id="upload-dropzone"
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
          onClick={triggerFileInput}
          className={`relative w-full aspect-video md:aspect-[16/10] rounded-xl border-2 border-dashed flex flex-col items-center justify-center p-6 text-center transition-all cursor-pointer ${
            isDragActive
              ? "border-emerald-500 bg-emerald-500/5"
              : "border-slate-800 bg-slate-900/30 hover:bg-slate-900/50 hover:border-slate-700"
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />

          <div className="p-4 rounded-full bg-slate-800/50 text-slate-400 mb-4 group-hover:scale-110 transition-transform">
            <Upload className="w-8 h-8 text-slate-300" />
          </div>

          <h3 className="font-display font-semibold text-base text-slate-200 mb-1">
            Upload Quotex Screenshot
          </h3>
          <p className="text-sm text-slate-400 max-w-sm mb-4">
            Drag and drop your file, click to browse, or paste directly using{" "}
            <kbd className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-xs">
              Ctrl + V
            </kbd>
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-mono text-slate-500">
            <span className="flex items-center gap-1">
              <ImageIcon className="w-3.5 h-3.5" /> PNG, JPG, WEBP
            </span>
            <span className="text-slate-700">•</span>
            <span className="flex items-center gap-1">
              <Clipboard className="w-3.5 h-3.5" /> Direct Paste Support
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
