import React from "react";
import { TradeHistoryItem } from "../types";
import { CheckCircle2, XCircle, Trash2, Calendar, TrendingUp, RefreshCw, BarChart2, Eye, ShieldAlert } from "lucide-react";
import HistoryVisualizer from "./HistoryVisualizer";

interface HistoryListProps {
  history: TradeHistoryItem[];
  onSetOutcome: (id: string, outcome: "WIN" | "LOSS") => void;
  onDelete: (id: string) => void;
  onClearAll: () => void;
  onLoadItem: (item: TradeHistoryItem) => void;
}

export default function HistoryList({
  history,
  onSetOutcome,
  onDelete,
  onClearAll,
  onLoadItem,
}: HistoryListProps) {
  // Statistics calculations
  const totalWithOutcome = history.filter((h) => h.userOutcome === "WIN" || h.userOutcome === "LOSS");
  const wins = history.filter((h) => h.userOutcome === "WIN").length;
  const losses = history.filter((h) => h.userOutcome === "LOSS").length;
  const winRate = totalWithOutcome.length > 0 ? Math.round((wins / totalWithOutcome.length) * 100) : 0;

  const formatDate = (isoStr: string) => {
    try {
      const date = new Date(isoStr);
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) + " " + date.toLocaleDateString([], { month: "short", day: "numeric" });
    } catch {
      return "Unknown Date";
    }
  };

  return (
    <div className="space-y-5 w-full">
      {/* Portfolio/History Stats Dashboard */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md">
        <div className="flex items-center justify-between gap-3 mb-4">
          <h3 className="font-display font-semibold text-slate-200 text-base flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-emerald-400" />
            AI Signal Tracker & Trading Journal
          </h3>
          {history.length > 0 && (
            <button
              onClick={onClearAll}
              className="text-xs text-rose-400 hover:text-rose-300 font-mono flex items-center gap-1 cursor-pointer transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" /> Clear All History
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-slate-950/50 rounded-lg p-3 border border-slate-800/60">
            <div className="text-[10px] font-mono text-slate-500 uppercase">Total Forecasts</div>
            <div className="text-xl font-mono font-bold text-slate-200">{history.length}</div>
          </div>

          <div className="bg-slate-950/50 rounded-lg p-3 border border-slate-800/60">
            <div className="text-[10px] font-mono text-slate-500 uppercase">Actual Wins</div>
            <div className="text-xl font-mono font-bold text-emerald-400">{wins}</div>
          </div>

          <div className="bg-slate-950/50 rounded-lg p-3 border border-slate-800/60">
            <div className="text-[10px] font-mono text-slate-500 uppercase">Actual Losses</div>
            <div className="text-xl font-mono font-bold text-rose-400">{losses}</div>
          </div>

          <div className="bg-slate-950/50 rounded-lg p-3 border border-slate-800/60 relative overflow-hidden group">
            <div className="text-[10px] font-mono text-slate-500 uppercase">Signal Win-Rate</div>
            <div className="text-xl font-mono font-bold text-slate-100 flex items-baseline gap-1">
              <span>{winRate}%</span>
              <span className="text-[10px] text-slate-500 font-sans">({totalWithOutcome.length} resolved)</span>
            </div>
            {/* Visual background spark */}
            {winRate >= 60 && (
              <div className="absolute right-0 bottom-0 top-0 w-1 bg-emerald-500/20" />
            )}
          </div>
        </div>
      </div>

      {/* Visualizer charts */}
      {history.length > 0 && (
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 shadow-sm">
          <HistoryVisualizer history={history} />
        </div>
      )}

      {/* History Items Container */}
      <div className="space-y-3">
        {history.length === 0 ? (
          <div className="text-center py-10 border border-dashed border-slate-800 rounded-xl bg-slate-900/10">
            <TrendingUp className="w-8 h-8 text-slate-700 mx-auto mb-2" />
            <p className="text-sm text-slate-500">Your trading analysis history is empty.</p>
            <p className="text-xs text-slate-600 mt-1">Upload and predict a Quotex screenshot to populate your journal.</p>
          </div>
        ) : (
          history.map((item) => {
            const isUp = item.prediction.prediction === "UP";
            const isDown = item.prediction.prediction === "DOWN";
            const isHold = item.prediction.prediction === "HOLD";

            return (
              <div
                key={item.id}
                className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 p-4 rounded-xl border border-slate-800 bg-slate-900/40 hover:bg-slate-900/85 transition-all group"
              >
                {/* Left Area: Thumbnail + Time + Action */}
                <div className="flex items-center gap-3.5">
                  <div className="relative w-16 aspect-video bg-slate-950 rounded border border-slate-800 overflow-hidden shrink-0">
                    <img
                      src={item.screenshotUrl}
                      alt="Thumbnail"
                      className="w-full h-full object-cover grayscale opacity-60 group-hover:grayscale-0 group-hover:opacity-90 transition-all"
                      referrerPolicy="no-referrer"
                    />
                    <button
                      onClick={() => onLoadItem(item)}
                      className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 flex items-center justify-center text-slate-200 transition-opacity cursor-pointer"
                      title="Enlarge & Inspect Prediction"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-xs font-bold font-mono px-1.5 py-0.5 rounded ${
                          isUp
                            ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/25"
                            : isDown
                            ? "bg-rose-500/10 text-rose-400 border border-rose-500/25"
                            : "bg-amber-500/10 text-amber-400 border border-amber-500/25"
                        }`}
                      >
                        {item.prediction.prediction}
                      </span>
                      <span className="text-xs font-mono text-slate-400">
                        {item.prediction.confidence}% Confidence
                      </span>
                      <span className="text-slate-600 font-mono text-xs">•</span>
                      <span className="text-[11px] font-mono text-slate-500 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                        ⏱ {item.prediction.recommendedTimeframe}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 text-xs text-slate-500 font-mono">
                      <Calendar className="w-3 h-3 text-slate-600" />
                      {formatDate(item.timestamp)}
                      {item.additionalContext && (
                        <>
                          <span className="text-slate-700">•</span>
                          <span className="truncate max-w-[150px] italic">"{item.additionalContext}"</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right Area: Trade Outcome Marker + Delete */}
                <div className="flex items-center justify-between md:justify-end gap-3 border-t md:border-t-0 border-slate-800/60 pt-3 md:pt-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-slate-500 uppercase tracking-wider hidden lg:inline">
                      Journal Outcome:
                    </span>

                    <button
                      onClick={() => onSetOutcome(item.id, "WIN")}
                      className={`px-2.5 py-1 rounded text-xs font-mono font-medium flex items-center gap-1 cursor-pointer border transition-all ${
                        item.userOutcome === "WIN"
                          ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/40"
                          : "bg-slate-950/40 text-slate-400 border-slate-800 hover:text-emerald-400 hover:border-emerald-500/30"
                      }`}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" /> WIN
                    </button>

                    <button
                      onClick={() => onSetOutcome(item.id, "LOSS")}
                      className={`px-2.5 py-1 rounded text-xs font-mono font-medium flex items-center gap-1 cursor-pointer border transition-all ${
                        item.userOutcome === "LOSS"
                          ? "bg-rose-500/20 text-rose-400 border-rose-500/40"
                          : "bg-slate-950/40 text-slate-400 border-slate-800 hover:text-rose-400 hover:border-rose-500/30"
                      }`}
                    >
                      <XCircle className="w-3.5 h-3.5" /> LOSS
                    </button>
                  </div>

                  <button
                    onClick={() => onDelete(item.id)}
                    className="p-1.5 rounded text-slate-500 hover:text-rose-400 hover:bg-rose-500/5 border border-transparent hover:border-rose-500/10 transition-colors cursor-pointer"
                    title="Delete record"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
