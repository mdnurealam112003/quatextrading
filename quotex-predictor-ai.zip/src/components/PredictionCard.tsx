import React from "react";
import { PredictionResult } from "../types";
import { ArrowUpRight, ArrowDownRight, Pause, ShieldAlert, Zap, Clock, Compass, Layers } from "lucide-react";

interface PredictionCardProps {
  prediction: PredictionResult;
  onSave?: () => void;
  isSaved?: boolean;
}

export default function PredictionCard({ prediction, onSave, isSaved }: PredictionCardProps) {
  const isUp = prediction.prediction === "UP";
  const isDown = prediction.prediction === "DOWN";
  const isHold = prediction.prediction === "HOLD";

  // Color mappings
  const bgTheme = isUp
    ? "bg-emerald-500/10 border-emerald-500/30"
    : isDown
    ? "bg-rose-500/10 border-rose-500/30"
    : "bg-amber-500/10 border-amber-500/30";

  const textTheme = isUp
    ? "text-emerald-400"
    : isDown
    ? "text-rose-400"
    : "text-amber-400";

  const buttonTheme = isUp
    ? "bg-emerald-500 hover:bg-emerald-600 text-slate-950"
    : isDown
    ? "bg-rose-500 hover:bg-rose-600 text-slate-950"
    : "bg-amber-500 hover:bg-amber-600 text-slate-950";

  return (
    <div className={`rounded-xl border ${bgTheme} p-6 shadow-xl transition-all w-full`}>
      {/* Upper Status Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/50 pb-5 mb-5">
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-lg ${isUp ? "bg-emerald-500/20" : isDown ? "bg-rose-500/20" : "bg-amber-500/20"}`}>
            {isUp && <ArrowUpRight className="w-6 h-6 text-emerald-400" />}
            {isDown && <ArrowDownRight className="w-6 h-6 text-rose-400" />}
            {isHold && <Pause className="w-6 h-6 text-amber-400" />}
          </div>
          <div>
            <div className="text-xs font-mono text-slate-400 uppercase tracking-widest">VERDICT SIGNAL</div>
            <h2 className="font-display font-bold text-2xl text-slate-100 flex items-center gap-2">
              {prediction.prediction === "UP" && <span className="text-emerald-400">UP (CALL / BUY)</span>}
              {prediction.prediction === "DOWN" && <span className="text-rose-400">DOWN (PUT / SELL)</span>}
              {prediction.prediction === "HOLD" && <span className="text-amber-400">HOLD (WAIT)</span>}
            </h2>
          </div>
        </div>

        {/* Confidence Circle/Meter */}
        <div className="flex items-center gap-4 bg-slate-950/40 border border-slate-800 px-4 py-2.5 rounded-lg">
          <div className="text-right">
            <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">CONFIDENCE</div>
            <div className="font-mono font-bold text-lg text-slate-100">{prediction.confidence}%</div>
          </div>
          <div className="w-10 h-10 relative flex items-center justify-center">
            {/* Simple circular confidence track */}
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="20"
                cy="20"
                r="16"
                className="stroke-slate-800 fill-none"
                strokeWidth="4"
              />
              <circle
                cx="20"
                cy="20"
                r="16"
                className={`fill-none ${
                  isUp ? "stroke-emerald-500" : isDown ? "stroke-rose-500" : "stroke-amber-500"
                }`}
                strokeWidth="4"
                strokeDasharray="100"
                strokeDashoffset={100 - prediction.confidence}
              />
            </svg>
          </div>
        </div>
      </div>

      {/* Grid details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="bg-slate-950/40 rounded-lg p-3.5 border border-slate-800/40">
          <div className="flex items-center gap-2 text-slate-400 text-xs font-mono uppercase mb-1.5">
            <Clock className="w-3.5 h-3.5 text-slate-500" />
            Timeframe Recomendation
          </div>
          <div className="font-display font-medium text-slate-200">
            {prediction.recommendedTimeframe}
          </div>
        </div>

        <div className="bg-slate-950/40 rounded-lg p-3.5 border border-slate-800/40">
          <div className="flex items-center gap-2 text-slate-400 text-xs font-mono uppercase mb-1.5">
            <ShieldAlert className="w-3.5 h-3.5 text-slate-500" />
            Risk Index
          </div>
          <div className="font-display font-semibold flex items-center gap-1.5">
            <span
              className={`inline-block w-2.5 h-2.5 rounded-full ${
                prediction.riskLevel === "LOW"
                  ? "bg-emerald-500"
                  : prediction.riskLevel === "MEDIUM"
                  ? "bg-amber-500"
                  : "bg-rose-500"
              }`}
            ></span>
            <span
              className={
                prediction.riskLevel === "LOW"
                  ? "text-emerald-400"
                  : prediction.riskLevel === "MEDIUM"
                  ? "text-amber-400"
                  : "text-rose-400"
              }
            >
              {prediction.riskLevel} RISK
            </span>
          </div>
        </div>
      </div>

      {/* Detected Patterns */}
      <div className="mb-6">
        <div className="flex items-center gap-2 text-slate-400 text-xs font-mono uppercase mb-2.5">
          <Layers className="w-3.5 h-3.5 text-slate-500" />
          Detected Candlestick & Market Patterns
        </div>
        <div className="flex flex-wrap gap-2">
          {prediction.keyPatterns.map((pattern, idx) => (
            <span
              key={idx}
              className="px-2.5 py-1 rounded bg-slate-800/80 border border-slate-700/60 text-xs font-mono text-slate-300"
            >
              {pattern}
            </span>
          ))}
          {prediction.keyPatterns.length === 0 && (
            <span className="text-slate-500 text-xs italic">No specific chart patterns isolated</span>
          )}
        </div>
      </div>

      {/* Analysis Details - Accordion or Stacked details */}
      <div className="space-y-4 mb-6 border-t border-slate-800/50 pt-5">
        <div>
          <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5 text-slate-500" /> Price Action & Structure
          </h4>
          <p className="text-sm text-slate-300 leading-relaxed bg-slate-900/30 p-3 rounded-lg border border-slate-800/40">
            {prediction.priceAction}
          </p>
        </div>

        <div>
          <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-slate-500" /> Indicators & Market Velocity
          </h4>
          <p className="text-sm text-slate-300 leading-relaxed bg-slate-900/30 p-3 rounded-lg border border-slate-800/40">
            {prediction.technicalIndicators}
          </p>
        </div>

        <div>
          <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-slate-500" /> Safety Entry Thresholds
          </h4>
          <p className="text-sm text-amber-300/90 leading-relaxed bg-amber-500/5 p-3 rounded-lg border border-amber-500/15">
            {prediction.safeMargin}
          </p>
        </div>

        <div>
          <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5 text-slate-500" /> Expert Rationale
          </h4>
          <p className="text-sm text-slate-300 leading-relaxed bg-slate-900/40 p-3.5 rounded-lg border border-slate-800">
            {prediction.justification}
          </p>
        </div>
      </div>

      {onSave && (
        <button
          onClick={onSave}
          disabled={isSaved}
          className={`w-full py-2.5 rounded-lg text-sm font-semibold tracking-wide transition-all ${
            isSaved
              ? "bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed"
              : "bg-slate-800 hover:bg-slate-750 text-slate-100 border border-slate-700 cursor-pointer"
          }`}
        >
          {isSaved ? "Saved to History Portfolio" : "Save Prediction to History Portfolio"}
        </button>
      )}
    </div>
  );
}
